// Original file: proto/chat.proto


export interface StreamMessage {
  'id'?: (number);
  'message'?: (string);
}

export interface StreamMessage__Output {
  'id'?: (number);
  'message'?: (string);
}
