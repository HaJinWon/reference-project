// Original file: proto/chat.proto


export interface InitiateRequest {
  'name'?: (string);
  'avartarUrl'?: (string);
}

export interface InitiateRequest__Output {
  'name'?: (string);
  'avartarUrl'?: (string);
}
