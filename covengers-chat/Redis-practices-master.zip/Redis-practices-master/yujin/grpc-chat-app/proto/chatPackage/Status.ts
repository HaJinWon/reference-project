// Original file: proto/chat.proto

export enum Status {
  UNKNOWN = 0,
  ONLINE = 1,
  OFFLINE = 2,
}
