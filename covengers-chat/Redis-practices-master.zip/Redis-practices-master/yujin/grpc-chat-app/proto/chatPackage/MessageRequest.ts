// Original file: proto/chat.proto


export interface MessageRequest {
  'id'?: (number);
  'message'?: (string);
}

export interface MessageRequest__Output {
  'id'?: (number);
  'message'?: (string);
}
