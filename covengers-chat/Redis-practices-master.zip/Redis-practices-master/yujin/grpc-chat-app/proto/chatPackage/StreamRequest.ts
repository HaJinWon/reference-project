// Original file: proto/chat.proto


export interface StreamRequest {
  'id'?: (number);
}

export interface StreamRequest__Output {
  'id'?: (number);
}
