// Original file: proto/chat.proto


export interface InitiateResponse {
  'id'?: (number);
}

export interface InitiateResponse__Output {
  'id'?: (number);
}
