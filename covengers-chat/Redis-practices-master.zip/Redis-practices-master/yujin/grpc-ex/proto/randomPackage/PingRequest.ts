// Original file: proto/chat.proto


export interface PingRequest {
  'message'?: (string);
}

export interface PingRequest__Output {
  'message'?: (string);
}
