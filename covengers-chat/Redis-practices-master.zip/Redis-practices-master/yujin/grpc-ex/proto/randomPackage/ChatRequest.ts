// Original file: proto/chat.proto


export interface ChatRequest {
  'message'?: (string);
}

export interface ChatRequest__Output {
  'message'?: (string);
}
