// Original file: proto/chat.proto


export interface NumberResponse {
  'num'?: (number);
}

export interface NumberResponse__Output {
  'num'?: (number);
}
