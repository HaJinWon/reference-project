// Original file: proto/chat.proto


export interface NumberRequest {
  'maxVal'?: (number);
}

export interface NumberRequest__Output {
  'maxVal'?: (number);
}
