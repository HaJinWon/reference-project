// Original file: proto/chat.proto


export interface TodoRequest {
  'todo'?: (string);
  'status'?: (string);
}

export interface TodoRequest__Output {
  'todo'?: (string);
  'status'?: (string);
}
