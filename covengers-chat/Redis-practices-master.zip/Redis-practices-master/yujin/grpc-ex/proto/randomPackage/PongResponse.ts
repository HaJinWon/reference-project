// Original file: proto/chat.proto


export interface PongResponse {
  'message'?: (string);
}

export interface PongResponse__Output {
  'message'?: (string);
}
