// Original file: proto/chat.proto


export interface ChatResponse {
  'username'?: (string);
  'message'?: (string);
}

export interface ChatResponse__Output {
  'username'?: (string);
  'message'?: (string);
}
