-- drop table

drop table chat;
drop table friend;
drop table participant;
drop table user;
drop table room;