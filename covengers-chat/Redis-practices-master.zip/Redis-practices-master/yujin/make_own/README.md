# make own chat room

* [chat-cord](chat-cord)
    * 실시간 chat : redis, socket.io
    * 저장소 : redis
    * react X
* [chat-cord-mysql](chat-cord-mysql)
    * 실시간 chat : redis, socket.io
    * 저장소 : mysql
    * react X