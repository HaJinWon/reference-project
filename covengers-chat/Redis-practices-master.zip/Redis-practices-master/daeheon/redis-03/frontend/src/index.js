import React from "react"
import { render } from 'react-dom';
import App from './login';

render(<App/>, document.getElementById('root'));
