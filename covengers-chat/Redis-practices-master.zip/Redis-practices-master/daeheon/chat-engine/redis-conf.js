module.exports = {
    host : "localhost",
    port : 6379,
    user : "redis",
    password : "root", //비밀번호가 설정되어 있는 경우
    auth : 'root'
}
