export const colors = {
    mainThemeColor: "#2C8AE8",
    lightMainThemeColor: "#2C8AE830",
    lightTextColor: "#636466"
}