import React from 'react';
import styled from 'styled-components';
import MainRouter from './routes/MainRouter';


export default function App() {

    return(
        <MainRouter />
    )
}