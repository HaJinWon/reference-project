import React from 'react';

export default function AlramSettingsTemplate() {

    return(
        <div>
            
        </div>
    );
}