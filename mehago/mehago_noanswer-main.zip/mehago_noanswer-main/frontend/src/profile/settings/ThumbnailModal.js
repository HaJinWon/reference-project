import React from 'react';

export default function ThumbnailModal() {

    return(
        <div>
            
        </div>
    )
}