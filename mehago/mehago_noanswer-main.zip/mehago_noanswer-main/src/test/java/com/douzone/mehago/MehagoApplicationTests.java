package com.douzone.mehago;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MehagoApplicationTests {

	@Test
	void contextLoads() {
	}

}
