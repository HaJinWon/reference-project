소켓 처리 
채팅방 정보 변경 >>>>> 네비게이션 바에서도 변경되어야 함
채팅방 삭제 >>> 소켓처리 필요

비회원????????

엘라스틱 서치 설정 elastcisearch.yml
https://needjarvis.tistory.com/680


elasticsearch 실행
``` bash
$ bin/elasticsearch
```

logstash