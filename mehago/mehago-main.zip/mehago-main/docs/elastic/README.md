### 설치

1. elastic search
2. logstash
3. apm-server
4. filebeat
5. kibana

### 환경변수 설정

제어판 > 시스템 >고급 > 환경변수

LOGSTASH_HOME : C:\elasticsearch\logstash-7.14.1 (logstash위치 )

cmd

%LOGSTASH_HOME%

<a href="https://www.aladin.co.kr/shop/ebook/wPreviewViewer.aspx?itemid=176342797">실전비급 엘라스틱 스택</a>