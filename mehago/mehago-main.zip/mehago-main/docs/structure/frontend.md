#### frontend

<pre>
    frontend
        |--- /config
        |       |--- babel.config.json
        |       |--- webpack.config.js
        |--- /public
        |       |--- /assets
        |       |       |--- /js
        |       |               |-- main.js
        |       |--- favicon.ico
        |       |--- index.html
        |--- /src
</pre>