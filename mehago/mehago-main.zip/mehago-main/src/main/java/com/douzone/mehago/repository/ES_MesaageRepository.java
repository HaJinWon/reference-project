package com.douzone.mehago.repository;

import java.util.List;

import com.douzone.mehago.entities.MessageEntity;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface ES_MesaageRepository extends ElasticsearchRepository<MessageEntity,Long>{
    
    List<MessageEntity> findByChatRoomNoAndMessageContaining(Long chatRoomNo, String searchKeyword);
}