package com.douzone.mehago;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MehagoApplication {
	public static void main(String[] args) {
		SpringApplication.run(MehagoApplication.class, args);
	}
}
