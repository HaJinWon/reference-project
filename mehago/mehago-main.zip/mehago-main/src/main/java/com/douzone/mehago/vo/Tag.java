package com.douzone.mehago.vo;

import lombok.Data;

@Data
public class Tag {
    private Long chatRoomNo;
    private Long no;
    private String name;
}