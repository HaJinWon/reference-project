import styled from 'styled-components';

const CircleDiv =styled.div`
    background-color:#fff;
    border:1px solid #ccc;
    border-radius: 100%;
`

export default CircleDiv;