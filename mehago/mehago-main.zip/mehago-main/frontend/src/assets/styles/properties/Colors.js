export const colors = {
    mainThemeColor: "#1C90FC",
    subThemeColor: "#38E0FA",
    lightTextColor: "#636466"
}